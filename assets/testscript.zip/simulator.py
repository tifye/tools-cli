def startMower():
    tifLinks.Discover(3000)
    node = tifLinks.Connect( "Main", 0, 1000 )
    tifUtils.SleepSeconds( 1 )
    node.Send("MowerApp.StartTrigger()")
