def awaitPosition():
    command = "LocalPosition.GetCoordinate2D()"

    x = 0
    y = 0
    while (x == 0 and y == 0):
        response = tifDevice.Send(command, 1000, silent = True)
        if response.ResponseResult == ResponseResult.Ok:
            x = response['x']
            y = response['y']
            tifUtils.SleepSeconds(1)
    tifConsole.Log("Starting at pos: {},{}".format(x,y))

def startTrigger():
    tifDevice.Send("StopButton.SetSimValue(stopButtonOnOff:1)")
    tifDevice.Send("StopButton.SetSimValue(stopButtonOnOff:0)")
    tifDevice.Send("ReferenceStation.SetInstalledPositionToCurrent()")
    tifDevice.Send("SystematicMissions.SetCompletedTestMode(enabled:1)")
    tifDevice.Send("MowerApp.SetMode(modeOfOperation:IMOWERAPP_MODE_AUTO)")
    tifDevice.Send("MowerApp.StartTrigger()")