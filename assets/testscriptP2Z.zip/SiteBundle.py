from System.IO import *

###############################################################################
#                     Copy a file to external flash
#
# FILENAME - The source file name which will be copied.
# TARGET_DIR - directory on target where the file shall be copied to.
#
###############################################################################

TARGET_DIR = 'Sites/'

SEND_TIMEOUT = 10000
CHUNK_SIZE = 200

def send( cmd, ms=SEND_TIMEOUT, silent=False ):
    result = tifDevice.Send( cmd, ms, silent )
    return result

def sendAssert( cmd, info, ms=SEND_TIMEOUT, silent=False ):
    response = tifDevice.Send( cmd, ms, silent )
    if response.ResponseResult == ResponseResult.Ok:
        tifTestRunner.Pass(info,info)
    else:
        tifTestRunner.Fail(info,info)
    return response

def OpenFile( filename ):
    # Open file created by create file test
    response = send("FileSystem.Open(volume:0, read:0, write:1, writeMode:FILESYSTEMTIF_WRITEMODE_TRUNCATE, create:1, path:" + filename + ")")
    # If response is OK
    if response.ResponseResult == ResponseResult.Ok:
        # Grab return value
        if 'file' in response.OutParameters:
            fh = response['file']
            tifTestRunner.Pass("OpenFile","OpenFile")
            return fh
        else:
            tifTestRunner.Fail("OpenFile","OpenFile")
            return None
    else:
        # No need to run close command if no file was created
        return None

def CloseFile( filehandle ):
    response = send( "FileSystem.Close(file:" + str(filehandle) + ")")
    if response.ResponseResult == ResponseResult.Ok:
        tifTestRunner.Pass("CloseFile","CloseFile")
    else:
        tifTestRunner.Fail("CloseFile","CloseFile")

def SendFile( srcFile, destFile ):
    tifConsole.Log( 'Write File: ' +  srcFile + ' as ' + destFile )
    fsFilehandle = OpenFile( destFile )
    if not fsFilehandle:
        tifConsole.Log( 'Failed to open file {}'.format(destFile), bold = True )
        return

    fileData = bytearray( File.ReadAllBytes(srcFile) )
    fileDataSize = len( fileData )

    tifFirmwareUpdate.SoftwareUpdateWillBegin( SoftwareType.None, srcFile, fileDataSize )
    tifFirmwareUpdate.SoftwareUpdateMessage( "{}".format( destFile ) )

    ok = True
    accBytesWritten = 0
    while accBytesWritten < fileDataSize and ok:
        dataChunk = fileData[ accBytesWritten:accBytesWritten + CHUNK_SIZE ]
        hexString = ''.join( [ "%02x" % x for x in dataChunk ] )
        response = send("FileSystem.Write(file:{}, length:{}, data:{})".format(fsFilehandle, len(dataChunk), hexString))
        ok = response.ResponseResult == ResponseResult.Ok
        if ok:
            accBytesWritten += len(dataChunk)
            progress = (100.0 * accBytesWritten) / fileDataSize
            tifFirmwareUpdate.SoftwareUpdateProgress( progress )

    CloseFile(fsFilehandle)

    if not ok:
        tifFirmwareUpdate.SoftwareUpdateFailed( "Failed after {} byte(s)".format( accBytesWritten ) )
        tifTestRunner.Fail("Upload","Upload")
    else:
        tifFirmwareUpdate.SoftwareUpdateCompleted()
        tifTestRunner.Pass("Upload","Upload")
    return ok

def uploadSiteMap(srcFile):
    destFile = "{}{}".format( TARGET_DIR, srcFile[srcFile.rfind("\\") + 1:] )
    startTime = time.time()
    SendFile( srcFile, destFile )
    elapsedTime = time.time() - startTime
    tifConsole.Log( 'Time: {:.3f} sec'.format( elapsedTime ), bold = True)
    setSiteMap( srcFile, destFile )

def setSiteMap( srcFile, destFile ):
    info = 'SiteMap set to: ' + destFile
    sendAssert( "SiteMap.SetSiteMapFilename(path:{})".format(destFile), info )

    info = 'SetUserValidatedChecksumFromFile '
    sendAssert( "SiteMap.SetUserValidatedChecksumFromFile()", info )

    info = 'GetSiteMapFilename'
    rsp = sendAssert( "SiteMap.GetSiteMapFilename()", info )
    tifTestRunner.AreEqual( rsp[ 'path' ], destFile, 'Path successful', 'Path successful' )

def deleteAllMissions():
    tifCommand = "Missions.GetNumberOfMissions()"
    response = sendAssert(tifCommand, tifCommand)
    numberOfMissions = int(response['numberOfMissions'])
    for i in reversed(range(numberOfMissions)):
        command = "Missions.GetIdListEntry(iterator:{})".format(i)
        response = sendAssert(command, command)
        id = response['missionId']
        command = "Missions.DeleteMission(missionId:{})".format(id)
        sendAssert(command, command)

def createMission(missionName, mowingArea, orientation=0, orientationShift=900, missionType = None, start=0, duration=23.00, missionId=None):
    if missionId is None:
        tifCommand = "Missions.CreateMission(name:{})".format(missionName)
        response = sendAssert(tifCommand, tifCommand)
        missionId = response['missionId']
    else:
        tifCommand = "Missions.CreateMissionWithId(missionId:{})".format(missionId)
        sendAssert(tifCommand, tifCommand)
        tifCommand = "Missions.SetName(missionId:{}, name:{})".format(missionId, missionName)
        sendAssert(tifCommand, tifCommand)

    tifConsole.Log("Created, mission %d" %(missionId))

    tifCommand = "Missions.SetMowingAreaId(missionId:{}, mowingArea:{})".format(missionId, mowingArea)
    response = sendAssert(tifCommand, tifCommand)

    if missionType == None:
        tifCommand = "Missions.GetMissionType(missionId:{})".format(missionId)
        response = sendAssert(tifCommand, tifCommand)
        missionType = response.OutParameters['missionType'].EnumKeyValue
    else:
        tifCommand = "Missions.SetMissionType(missionId:{}, missionType:{})".format(missionId, missionType)
        response = sendAssert(tifCommand, tifCommand)

    if missionType == "IMISSIONS_TYPE_SYSTEMATIC":
        if orientation == "Calculate":
            tifCommand = "SystematicMissions.CalculateOrientation(missionId:{})".format(missionId)
            tifUtils.SleepSeconds(2) # command blocks next setting
            response = sendAssert(tifCommand, tifCommand)
        else:
            tifCommand = "SystematicMissions.SetOrientation(missionId:{}, orientation:{})".format(missionId, orientation)
            response = sendAssert(tifCommand, tifCommand)

        tifCommand = "SystematicMissions.SetOrientationShift(missionId:{}, orientationShift:{})".format(missionId, orientationShift)
        response = sendAssert(tifCommand, tifCommand)

    setCalendarTaskForMission(missionId, start, duration)

def setCalendarTaskForMission(missionId, start=0, duration = 23.0):
    startL = "{0:.2f}".format(float(start)).split('.')
    startHour = int(startL[0])
    startMin = int(startL[1])
    durationL = "{0:.2f}".format(float(duration)).split('.')
    durationHour = int(durationL[0])
    durationMin = int(durationL[1])
    startSec = startMin*60 + 60*60*startHour
    durationSec = durationMin*60 + 60*60*durationHour

    command = "Calendar.AddTaskWithMission(start:{}, duration:{},".format(int(startSec), int(durationSec))
    command += "useOnMonday:1, useOnTuesday:1, useOnWednesday:1, useOnThursday:1, useOnFriday:1, useOnSaturday:1, useOnSunday:1,"
    command += "missionId:{})".format(missionId)
    sendAssert(command, command)

def deleteAllCalendarTasks():
    tifCommand = "Calendar.DeleteAllTasks()"
    sendAssert(tifCommand, tifCommand)

def createCalendarTasks():
    tifCommand = "Calendar.DeleteAllTasks()"
    sendAssert(tifCommand, tifCommand)

    tifCommand = "Missions.GetNumberOfMissions()"
    response = sendAssert(tifCommand, tifCommand)
    numberOfMissions = int(response['numberOfMissions'])
    for i in reversed(range(numberOfMissions)):
        command = "Missions.GetIdListEntry(iterator:{})".format(i)
        response = sendAssert(command, command)
        id = response['missionId']
        command = "Calendar.AddTaskWithMission(start:0, duration:86399, useOnMonday:1, useOnTuesday:1, useOnWednesday:1, useOnThursday:1, useOnFriday:1, useOnSaturday:1, useOnSunday:1, missionId:{})".format(id)
        sendAssert(command, command)



